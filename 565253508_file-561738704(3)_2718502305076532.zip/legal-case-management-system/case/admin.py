from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(client_detail)

admin.site.register(team_member)

admin.site.register(appiontment)

admin.site.register(court)

admin.site.register(court_type)

admin.site.register(services)

